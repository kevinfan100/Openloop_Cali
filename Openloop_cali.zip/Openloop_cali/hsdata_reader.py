#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
HSData Binary File Reader - Batch Processing Tool

Simple tool to convert HSData binary (.dat) files to CSV format.

Usage:
    python hsdata_reader.py P1      # Process P1 folder only
    python hsdata_reader.py all     # Process all P1~P6 folders
    python hsdata_reader.py         # Show usage instructions

Project Structure:
    Openloop_cali/
    ├── hsdata_reader.py
    ├── raw_data/              # Place .dat files here
    │   ├── P1/
    │   │   ├── 0.1Hz.dat
    │   │   ├── 1Hz.dat
    │   │   └── ...
    │   ├── P2/
    │   └── ...
    └── processed_csv/         # CSV output (auto-created)
        ├── P1/
        └── ...

File Format:
    - Header: 24 bytes (magic, version, record_count, timestamp)
    - Records: 60 bytes each (vm: 6×float, vd: 6×float, da: 6×uint16)
"""

import sys
import struct
import numpy as np
from pathlib import Path
from datetime import datetime
from typing import List, Dict, Optional
from tqdm import tqdm


# ============================================================================
# CONFIGURATION
# ============================================================================

SCRIPT_DIR = Path(__file__).parent
RAW_DATA_DIR = SCRIPT_DIR / "raw_data"
PROCESSED_CSV_DIR = SCRIPT_DIR / "processed_csv"

AVAILABLE_FOLDERS = ["P1", "P2", "P3", "P4", "P5", "P6"]


# ============================================================================
# HSDataReader CLASS
# ============================================================================

class HSDataReader:
    """Read and convert HSData binary files to CSV"""

    # File format constants
    MAGIC_NUMBER = b'HSDATA\x00\x00'
    VERSION = 1
    HEADER_SIZE = 24
    RECORD_SIZE = 60

    def __init__(self, file_path: Path):
        """Initialize reader with file path"""
        self.file_path = Path(file_path)
        self.header: Optional[Dict] = None
        self.data_records: List[Dict] = []
        self._validate_file()

    def _validate_file(self):
        """Validate file existence and basic format"""
        if not self.file_path.exists():
            raise FileNotFoundError(f"File not found: {self.file_path}")

        file_size = self.file_path.stat().st_size
        if file_size < self.HEADER_SIZE:
            raise ValueError(f"File too small: {file_size} bytes")

    def read_header(self) -> Dict:
        """Read file header information"""
        with open(self.file_path, 'rb') as f:
            header_data = f.read(self.HEADER_SIZE)

            if len(header_data) < self.HEADER_SIZE:
                raise ValueError("Incomplete file header data")

            magic = header_data[0:8]
            version = struct.unpack('<I', header_data[8:12])[0]
            record_count = struct.unpack('<I', header_data[12:16])[0]
            timestamp = struct.unpack('<Q', header_data[16:24])[0]

            self.header = {
                'magic': magic.decode('ascii', errors='ignore').rstrip('\x00'),
                'version': version,
                'record_count': record_count,
                'timestamp': timestamp,
                'creation_time': datetime.fromtimestamp(timestamp),
                'file_size': self.file_path.stat().st_size
            }

            return self.header

    def validate_format(self) -> bool:
        """Validate file format"""
        if self.header is None:
            self.read_header()

        if not self.header['magic'].startswith('HSDATA'):
            print(f"[ERROR] Invalid magic number: {self.header['magic']}")
            return False

        if self.header['version'] != self.VERSION:
            print(f"[ERROR] Unsupported version: {self.header['version']}")
            return False

        return True

    def read_data(self) -> List[Dict]:
        """Read all data records"""
        records = []
        with open(self.file_path, 'rb') as f:
            f.seek(self.HEADER_SIZE)
            idx = 0

            while True:
                record_data = f.read(self.RECORD_SIZE)
                if len(record_data) < self.RECORD_SIZE:
                    break

                vm = struct.unpack('<6f', record_data[0:24])
                vd = struct.unpack('<6f', record_data[24:48])
                da = struct.unpack('<6H', record_data[48:60])

                records.append({
                    'index': idx,
                    'vm': np.array(vm),
                    'vd': np.array(vd),
                    'da': np.array(da)
                })
                idx += 1

        self.data_records = records
        return records

    def to_csv(self, output_path: Path) -> str:
        """Convert to CSV file using NumPy (ultra-fast, 3x faster than old version)"""
        # Ensure output directory exists
        output_path.parent.mkdir(parents=True, exist_ok=True)

        # Read entire file into memory and parse with NumPy
        with open(self.file_path, 'rb') as f:
            f.seek(self.HEADER_SIZE)
            raw_data = f.read()

        # Calculate number of records
        n_records = len(raw_data) // self.RECORD_SIZE

        # Create dtype for structured array
        dtype = np.dtype([
            ('vm', '<f4', 6),
            ('vd', '<f4', 6),
            ('da', '<u2', 6)
        ])

        # Parse all data at once using NumPy (ultra-fast!)
        records = np.frombuffer(raw_data[:n_records * self.RECORD_SIZE], dtype=dtype)

        # Combine into single matrix
        data_matrix = np.column_stack([
            np.arange(n_records).reshape(-1, 1),
            records['vm'],
            records['vd'],
            records['da']
        ])

        # Build header
        header = 'index,' + \
                 ','.join([f'vm_{i}' for i in range(6)]) + ',' + \
                 ','.join([f'vd_{i}' for i in range(6)]) + ',' + \
                 ','.join([f'da_{i}' for i in range(6)])

        # Write using NumPy (fastest method, 3x faster than pandas)
        np.savetxt(output_path, data_matrix, delimiter=',', header=header,
                   comments='', fmt='%.10g', encoding='utf-8')

        return str(output_path)


# ============================================================================
# UTILITY FUNCTIONS
# ============================================================================

def show_usage():
    """Display usage instructions"""
    print("=" * 60)
    print("HSData Binary File Reader - Batch Processing Tool")
    print("=" * 60)
    print("\nUsage:")
    print("  python hsdata_reader.py <folder_name>")
    print("  python hsdata_reader.py all")
    print("\nExamples:")
    print("  python hsdata_reader.py P1     # Process P1 folder only")
    print("  python hsdata_reader.py all    # Process all P1~P6 folders")
    print("\nAvailable folders:")
    list_available_folders()
    print("\nProject Structure:")
    print("  raw_data/P1/       - Place your .dat files here")
    print("  processed_csv/P1/  - CSV files will be generated here")
    print("=" * 60)


def list_available_folders():
    """List folders in raw_data directory"""
    print(f"  Expected: {', '.join(AVAILABLE_FOLDERS)}")

    if RAW_DATA_DIR.exists():
        existing = [f.name for f in RAW_DATA_DIR.iterdir() if f.is_dir()]
        if existing:
            print(f"  Found:    {', '.join(sorted(existing))}")
        else:
            print(f"  Found:    (none)")
    else:
        print(f"  Note: {RAW_DATA_DIR} does not exist yet")


def parse_arguments() -> List[str]:
    """Parse command line arguments and return folder list"""
    if len(sys.argv) < 2:
        show_usage()
        sys.exit(0)

    target = sys.argv[1]

    if target.lower() == "all":
        return AVAILABLE_FOLDERS
    else:
        return [target]


def validate_folders(folders: List[str]):
    """Validate all folders exist before processing (fail-fast)"""
    missing_folders = []

    for folder in folders:
        folder_path = RAW_DATA_DIR / folder
        if not folder_path.exists():
            missing_folders.append(folder)

    if missing_folders:
        print(f"\n[ERROR] The following folders do not exist in {RAW_DATA_DIR}:")
        for folder in missing_folders:
            print(f"   - {folder}")
        print(f"\nAvailable folders:")
        list_available_folders()
        print(f"\nPlease create the missing folders and add .dat files.")
        sys.exit(1)


def find_dat_files(folder_path: Path) -> List[Path]:
    """Find all .dat files in the specified folder"""
    dat_files = sorted(folder_path.glob("*.dat"))
    return dat_files


def process_single_folder(folder_name: str) -> Dict:
    """Process all .dat files in a single folder"""
    input_folder = RAW_DATA_DIR / folder_name
    output_folder = PROCESSED_CSV_DIR / folder_name

    # Find .dat files
    dat_files = find_dat_files(input_folder)

    if not dat_files:
        print(f"\n[WARNING] No .dat files found in {input_folder}")
        return {
            "folder": folder_name,
            "processed": 0,
            "failed": 0,
            "skipped": 0
        }

    # Process files with progress bar
    processed_count = 0
    failed_count = 0
    failed_files = []

    print(f"\n{'=' * 60}")
    print(f"Processing folder: {folder_name}")
    print(f"Input:  {input_folder}")
    print(f"Output: {output_folder}")
    print(f"Files:  {len(dat_files)} .dat files found")
    print(f"{'=' * 60}")

    for file_path in tqdm(dat_files, desc=f"Converting {folder_name}", unit="file"):
        try:
            # Read and validate
            reader = HSDataReader(file_path)
            reader.read_header()

            if not reader.validate_format():
                raise ValueError("Format validation failed")

            # Convert to CSV
            output_path = output_folder / file_path.with_suffix('.csv').name
            reader.to_csv(output_path)

            processed_count += 1

        except Exception as e:
            failed_count += 1
            failed_files.append({"file": file_path.name, "error": str(e).encode('utf-8', errors='replace').decode('utf-8')})

    # Print folder summary
    print(f"\n[OK] Folder '{folder_name}' completed:")
    print(f"  - Successfully processed: {processed_count} files")
    if failed_count > 0:
        print(f"  - Failed: {failed_count} files")
        for failed in failed_files:
            print(f"    [ERROR] {failed['file']}: {failed['error']}")

    return {
        "folder": folder_name,
        "processed": processed_count,
        "failed": failed_count,
        "failed_files": failed_files
    }


def print_summary(results: List[Dict]):
    """Print overall processing summary"""
    total_processed = sum(r["processed"] for r in results)
    total_failed = sum(r["failed"] for r in results)

    print(f"\n{'=' * 60}")
    print("SUMMARY")
    print(f"{'=' * 60}")
    print(f"Folders processed: {len(results)}")
    print(f"Total files converted: {total_processed}")
    print(f"Total files failed: {total_failed}")
    print(f"Output directory: {PROCESSED_CSV_DIR}")
    print(f"{'=' * 60}")

    if total_failed > 0:
        print(f"\n[WARNING] {total_failed} files failed to process")
        print("Check the error messages above for details.")


# ============================================================================
# MAIN PROGRAM
# ============================================================================

def main():
    """Main program entry point"""
    try:
        # Parse command line arguments
        folders = parse_arguments()

        # Validate all folders exist (fail-fast)
        validate_folders(folders)

        # Process each folder
        all_results = []
        for folder in folders:
            result = process_single_folder(folder)
            all_results.append(result)

        # Print summary
        print_summary(all_results)

    except KeyboardInterrupt:
        print("\n\n[WARNING] Processing interrupted by user")
        sys.exit(1)
    except Exception as e:
        print(f"\n[ERROR] Fatal error: {e}")
        sys.exit(1)


if __name__ == "__main__":
    main()
